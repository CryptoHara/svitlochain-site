#!/usr/bin/env python3
"""
Svitlo Fleet CLI — реєстрація та управління GPU-фермою

Команди:
  register --config fleet.json --key svit_ent_...   Зареєструвати всі ноди
  status   --key svit_ent_...                        Онлайн-статус ферми
  stats    --key svit_ent_... [--days 7]             Доходи за N днів
  account  --key svit_ent_...                        Інфо про тир і комісію

fleet.json приклад:
  {
    "nodes": [
      {
        "name": "rig-01",
        "endpoint_url": "http://10.0.0.5:8001",
        "gpu_specs": [{"name": "RTX 3090", "vram_gb": 24}],
        "capabilities": ["llm", "image_gen", "stt"],
        "image_gen_models": ["flux-schnell", "sdxl"],
        "stt_models": ["whisper-large-v3"],
        "price_per_image": 0.005,
        "region": "EU",
        "compliance": ["GDPR"]
      }
    ]
  }
"""
import argparse
import json
import sys
import os
import urllib.request
import urllib.error

# API URL — можна перевизначити через SVITLO_API_URL
# svitlo.network never resolved (confirmed 2026-08-10, getent hosts fails) --
# stale from before the domain settled on svitlochain.com. Real reachable
# endpoint today (see gui/app.py's PLATFORM_URL_DEFAULT / run_linux.sh's
# comment): the platform backend behind svitlo-edge-proxy, sharing
# genesis2's ngrok tunnel, until api.svitlochain.com gets a real DNS record.
API_URL = os.environ.get("SVITLO_API_URL", "https://dares-suffering-swimwear.ngrok-free.dev/api/v1")

TIER_COLORS = {
    "starter": "\033[33m",   # yellow
    "growth":  "\033[36m",   # cyan
    "scale":   "\033[32m",   # green
    "partner": "\033[35m",   # magenta
}
RESET = "\033[0m"
BOLD  = "\033[1m"
DIM   = "\033[2m"
GREEN = "\033[32m"
RED   = "\033[31m"
CYAN  = "\033[36m"
YELLOW= "\033[33m"


def _no_color():
    return not sys.stdout.isatty() or os.environ.get("NO_COLOR")


def _c(code, text):
    return text if _no_color() else f"{code}{text}{RESET}"


def _api(method: str, path: str, body=None, key: str = "") -> dict:
    url = f"{API_URL}{path}"
    data = json.dumps(body).encode() if body else None
    headers = {"Content-Type": "application/json"}
    if key:
        headers["X-Enterprise-Key"] = key
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        err = json.loads(e.read())
        print(_c(RED, f"\n  Error {e.code}: {err.get('detail', e.reason)}"))
        sys.exit(1)
    except urllib.error.URLError as e:
        print(_c(RED, f"\n  Connection error: {e.reason}"))
        print(f"  API URL: {API_URL}")
        print(f"  Set SVITLO_API_URL env var to override.")
        sys.exit(1)


def _table(headers: list, rows: list, widths: list = None):
    if not widths:
        widths = [max(len(str(r[i])) for r in ([headers] + rows)) for i in range(len(headers))]
    fmt = "  " + "  ".join(f"{{:<{w}}}" for w in widths)
    sep = "  " + "  ".join("-" * w for w in widths)
    print(_c(DIM, fmt.format(*headers)))
    print(_c(DIM, sep))
    for row in rows:
        print(fmt.format(*[str(x) for x in row]))


# ── Commands ───────────────────────────────────────────────────────────────────

def cmd_register(args):
    """Масова реєстрація нод з fleet.json."""
    try:
        with open(args.config) as f:
            fleet_data = json.load(f)
    except FileNotFoundError:
        print(_c(RED, f"  File not found: {args.config}"))
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(_c(RED, f"  Invalid JSON in {args.config}: {e}"))
        sys.exit(1)

    nodes = fleet_data.get("nodes", [])
    if not nodes:
        print(_c(RED, "  fleet.json has no nodes"))
        sys.exit(1)

    print(f"\n{_c(BOLD, 'Svitlo Fleet Registration')}")
    print(f"  Config:  {args.config}")
    print(f"  Nodes:   {len(nodes)}")
    print(f"  API:     {API_URL}\n")

    result = _api("POST", "/enterprise/fleet/register", {"nodes": nodes}, key=args.key)

    print(_c(GREEN, f"  ✓ {result['registered_count']} nodes registered\n"))

    tier_col = TIER_COLORS.get(result["tier"], "")
    rows = [[n["name"], n["node_id"][:16] + "..."] for n in result["nodes"]]
    _table(["Name", "Node ID"], rows)

    print(f"\n  Fleet total: {result['fleet_total_nodes']} nodes, {result['gpu_count']} GPUs")
    print(f"  Tier:        {_c(tier_col + BOLD, result['tier_label'].upper())}")
    print(f"  Commission:  {int(result['commission_pct']*100)}%  →  You earn {int(result['node_earnings_pct']*100)}%")

    if result.get("message"):
        print(f"\n  {_c(DIM, result['message'])}")


def cmd_status(args):
    """Онлайн-статус кожної ноди."""
    result = _api("GET", "/enterprise/fleet/status", key=args.key)

    total   = result["fleet_size"]
    online  = result["online"]
    offline = result["offline"]
    earned  = result["total_earned"]

    status_color = GREEN if online == total else (YELLOW if online > 0 else RED)

    print(f"\n{_c(BOLD, 'Fleet Status')}")
    print(f"  Online:  {_c(status_color, f'{online}/{total}')}")
    print(f"  Earned:  {earned:.4f} SVIT (all time)\n")

    rows = []
    for n in result["nodes"]:
        st = n["status"]
        st_str = _c(GREEN, "● online") if st == "online" else _c(RED, "○ offline")
        util = f"{n['gpu_utilization']*100:.1f}%"
        rows.append([n["name"], st_str, util, str(n["jobs_completed"]), f"${n['earned_svit']:.4f}"])
    _table(["Name", "Status", "GPU util", "Jobs", "Earned SVIT"], rows)


def cmd_stats(args):
    """Доходи та завантаженість за N днів."""
    result = _api("GET", f"/enterprise/fleet/stats?days={args.days}", key=args.key)

    period_days = result["period_days"]
    print(f"\n{_c(BOLD, f'Fleet Stats — last {period_days} days')}")
    print(f"  Total earned:     {result['total_earned']:.4f} SVIT")
    print(f"  Total jobs:       {result['total_jobs']}")
    print(f"  Avg utilization:  {result['avg_utilization_pct']}%\n")

    rows = []
    for n in result["nodes"]:
        util_color = GREEN if n["utilization_pct"] >= 40 else (YELLOW if n["utilization_pct"] >= 10 else RED)
        rows.append([
            n["name"],
            str(n["jobs_completed"]),
            f"{n['tokens_generated']:,}",
            _c(util_color, f"{n['utilization_pct']}%"),
            f"${n['earned_svit']:.4f}",
        ])
    _table(["Node", "Jobs", "Tokens", "Util", "Earned SVIT"], rows)

    if result["total_earned"] > 0 and result["total_jobs"] > 0:
        avg_per_job = result["total_earned"] / result["total_jobs"]
        daily = result["total_earned"] / result["period_days"]
        print(f"\n  Avg per job: ${avg_per_job:.6f}")
        print(f"  Daily avg:   ${daily:.4f}")
        print(f"  Monthly est: ${daily * 30:.2f}")


def cmd_account(args):
    """Інфо про тир, комісію, доходи."""
    a = _api("GET", "/enterprise/account", key=args.key)

    tier_col = TIER_COLORS.get(a["tier"], "")
    print(f"\n{_c(BOLD, a['company_name'])}  ·  Enterprise Account")
    print(f"  Enterprise ID:   {a['enterprise_id']}")
    print(f"  Wallet:          {a['wallet']}")
    print()
    print(f"  Tier:            {_c(tier_col + BOLD, a['tier_label'].upper())}")
    print(f"  Commission:      {int(a['commission_pct']*100)}%  →  You earn {int(a['node_earnings_pct']*100)}%")
    print(f"  Nodes / GPUs:    {a['node_count']} nodes / {a['gpu_count']} GPUs")
    print()
    print(f"  Total earned:    {a['total_earned_svit']:.4f} SVIT")
    print(f"  Total jobs:      {a['total_jobs']}")
    print(f"  Status:          {_c(GREEN, a['status'])}")

    if a.get("next_tier"):
        nt = a["next_tier"]
        nt_col = TIER_COLORS.get(nt["tier"], "")
        print(f"\n  {_c(DIM, '──')} Next tier: {_c(nt_col + BOLD, nt['label'].upper())} ({int(nt['commission_pct']*100)}% fee)")
        print(f"  {_c(DIM, nt['message'])}")


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="fleet_cli.py",
        description="Svitlo Fleet CLI — manage your GPU farm",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # register
    p_reg = sub.add_parser("register", help="Bulk-register nodes from fleet.json")
    p_reg.add_argument("--config", "-c", default="fleet.json", help="Path to fleet.json")
    p_reg.add_argument("--key",    "-k", required=True, metavar="API_KEY", help="Enterprise API key (svit_ent_...)")

    # status
    p_st = sub.add_parser("status", help="Live status of all nodes")
    p_st.add_argument("--key", "-k", required=True, metavar="API_KEY")

    # stats
    p_stats = sub.add_parser("stats", help="Earnings and utilization report")
    p_stats.add_argument("--key",  "-k", required=True, metavar="API_KEY")
    p_stats.add_argument("--days", "-d", type=int, default=7, metavar="N")

    # account
    p_acc = sub.add_parser("account", help="Account info: tier, commission, totals")
    p_acc.add_argument("--key", "-k", required=True, metavar="API_KEY")

    args = parser.parse_args()
    dispatch = {"register": cmd_register, "status": cmd_status, "stats": cmd_stats, "account": cmd_account}
    dispatch[args.cmd](args)
    print()


if __name__ == "__main__":
    main()
