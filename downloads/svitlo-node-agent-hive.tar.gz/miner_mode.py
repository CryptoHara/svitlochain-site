"""
Svitlo Miner Mode — авто-перемикання між AI jobs і крипто-майнінгом.

Логіка:
  Немає AI jobs > MINE_IDLE_S секунд → запускаємо майнер
  Прийшов AI job               → зупиняємо майнер, обробляємо, відновлюємо
  AI job більше MINE_RESUME_S  → відновлюємо майнінг

Підтримувані монети (2026):
  Kaspa (KAS) — найкращий для NVIDIA/AMD (KHeavyHash)
  Ergo (ERG)  — autolykos2, хороший для RTX
  ETC         — etchash (NVIDIA/AMD)

Підтримувані майнери (авто-детекція):
  kaspa-miner, bzminer, gminer, lolminer, teamredminer, srbminer
"""

import json
import os
import platform
import re
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


MINE_IDLE_S   = int(os.environ.get("SVITLO_MINE_IDLE_S",   "300"))   # 5 хв без job → старт майнінгу
MINE_RESUME_S = int(os.environ.get("SVITLO_MINE_RESUME_S", "60"))    # 60с після job → відновити
MINE_COIN     = os.environ.get("SVITLO_MINE_COIN", "auto")           # "auto" | "kas" | "etc" | "erg"
SYS           = platform.system()

# Kaspa пули (public, без реєстрації)
KAS_POOLS = [
    "stratum+tcp://pool.woolypooly.com:3112",
    "stratum+tcp://kas.f2pool.com:16556",
    "stratum+tcp://kas.kryptex.network:8888",
]

# ETC пули
ETC_POOLS = [
    "stratum+tcp://eu1.ethermine.org:4444",
    "stratum+tcp://etc.2miners.com:1010",
]

# ERG пули
ERG_POOLS = [
    "stratum+tcp://erg.woolypooly.com:3100",
    "stratum+tcp://ergo.2miners.com:8008",
]


@dataclass
class MiningStats:
    running:         bool  = False
    coin:            str   = ""
    miner_name:      str   = ""
    hashrate_str:    str   = ""    # e.g. "1.47 GH/s"
    shares_accepted: int   = 0
    estimated_24h:   float = 0.0   # USD/24h estimate
    started_at:      float = 0.0
    stopped_at:      float = 0.0


class MinerMode:
    """
    Запускається як daemon thread в node agent.
    Комунікує з agent через callbacks та `job_arrived()` / `job_done()`.
    """

    def __init__(self, wallet_address: str, on_stats_update=None):
        self.wallet        = wallet_address
        self._proc:   Optional[subprocess.Popen] = None
        self._stats   = MiningStats()
        self._lock    = threading.Lock()
        self._stop    = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_job_time = 0.0
        self._job_active    = False
        self._on_update     = on_stats_update

        # Визначаємо який майнер і монету використовувати
        self._miner_path, self._miner_name = self._find_miner()
        self._coin = self._choose_coin()

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Запускаємо фоновий monitor thread."""
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True, name="miner-mode")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._stop_mining()
        if self._thread:
            self._thread.join(timeout=5)

    def job_arrived(self) -> None:
        """Викликати коли платформа прислала AI job."""
        self._job_active    = True
        self._last_job_time = time.time()
        self._stop_mining()

    def job_done(self) -> None:
        """Викликати після завершення AI job."""
        self._job_active    = False
        self._last_job_time = time.time()

    def get_stats(self) -> MiningStats:
        with self._lock:
            return self._stats

    def is_available(self) -> bool:
        return self._miner_path is not None and bool(self.wallet)

    # ── Mining control ────────────────────────────────────────────────────────

    def _monitor_loop(self) -> None:
        while not self._stop.is_set():
            if not self._job_active and not self._stats.running:
                idle_s = time.time() - self._last_job_time
                if idle_s >= MINE_IDLE_S or self._last_job_time == 0:
                    self._start_mining()

            # Перевіряємо чи майнер ще живий
            if self._stats.running and self._proc:
                if self._proc.poll() is not None:
                    with self._lock:
                        self._stats.running = False
                    print(f"[MinerMode] Miner stopped unexpectedly (exit={self._proc.returncode})")

            self._stop.wait(timeout=10)

    def _start_mining(self) -> None:
        if not self.is_available():
            return
        if self._stats.running:
            return

        cmd = self._build_cmd()
        if not cmd:
            return

        try:
            self._proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            with self._lock:
                self._stats.running      = True
                self._stats.coin         = self._coin
                self._stats.miner_name   = self._miner_name
                self._stats.started_at   = time.time()
                self._stats.hashrate_str = "starting..."

            print(f"[MinerMode] ⛏  Mining {self._coin.upper()} with {self._miner_name}")
            threading.Thread(target=self._read_output, daemon=True).start()

        except Exception as e:
            print(f"[MinerMode] Failed to start miner: {e}")

    def _stop_mining(self) -> None:
        if not self._stats.running:
            return
        if self._proc and self._proc.poll() is None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=8)
            except subprocess.TimeoutExpired:
                self._proc.kill()

        with self._lock:
            self._stats.running    = False
            self._stats.stopped_at = time.time()
            self._stats.hashrate_str = ""
        print("[MinerMode] ⏸  Mining paused — AI job active")
        if self._on_update:
            self._on_update(self._stats)

    def _read_output(self) -> None:
        """Парсимо stdout майнера для отримання hashrate."""
        if not self._proc:
            return
        for line in self._proc.stdout:
            line = line.strip()
            if not line:
                continue
            # Парсимо hashrate з різних майнерів
            hr = self._parse_hashrate(line)
            if hr:
                with self._lock:
                    self._stats.hashrate_str = hr
                    self._stats.estimated_24h = self._estimate_earnings(hr)
                if self._on_update:
                    self._on_update(self._stats)
            # Shares
            if "accepted" in line.lower() or "share" in line.lower():
                with self._lock:
                    self._stats.shares_accepted += 1

    def _parse_hashrate(self, line: str) -> Optional[str]:
        """Витягуємо hashrate з виводу різних майнерів."""
        # bzminer, gminer, lolminer: "1.47 GH/s" або "1470 MH/s"
        patterns = [
            r"(\d+[\.,]\d+)\s*(GH/s|MH/s|KH/s|TH/s)",
            r"(\d+[\.,]\d+)\s*Gh/s",
            r"total:\s*(\d+[\.,]\d+)\s*(GH|MH|KH)",
            r"Hashrate:\s*([\d.,]+)\s*(GH|MH|KH)",
        ]
        for pat in patterns:
            m = re.search(pat, line, re.IGNORECASE)
            if m:
                return f"{m.group(1)} {m.group(2) if len(m.groups()) > 1 else 'MH/s'}"
        return None

    def _estimate_earnings(self, hashrate_str: str) -> float:
        """Груба оцінка USD/24h на основі hashrate (Kaspa 2026)."""
        try:
            val = float(hashrate_str.split()[0].replace(",", "."))
            unit = hashrate_str.split()[1].upper() if len(hashrate_str.split()) > 1 else "MH/S"
            # Нормалізуємо до GH/s
            if "MH" in unit:  val /= 1000
            elif "KH" in unit: val /= 1_000_000
            elif "TH" in unit: val *= 1000
            # KAS приблизна оцінка: 1 GH/s ≈ $0.015/day (2026 estimate, varies greatly)
            return round(val * 0.015, 3)
        except Exception:
            return 0.0

    # ── Command building ──────────────────────────────────────────────────────

    def _build_cmd(self) -> Optional[list]:
        if not self._miner_path:
            return None
        m = self._miner_name
        w = self.wallet

        if self._coin == "kas":
            pool = KAS_POOLS[0]
            if "bzminer" in m:
                return [self._miner_path, "-a", "kaspa", "-o", pool, "-w", w]
            elif "gminer" in m:
                return [self._miner_path, "--algo", "kheavyhash", "--server", pool.split("//")[1].split(":")[0],
                        "--port", pool.split(":")[-1], "--user", w]
            elif "lolminer" in m:
                return [self._miner_path, "--algo", "KASPA", "--pool", pool, "--user", w]
            elif "kaspa-miner" in m:
                host, port = pool.replace("stratum+tcp://", "").split(":")
                return [self._miner_path, f"--mining-address={w}", f"--server={host}", f"--port={port}"]
            else:
                # Загальний формат для більшості майнерів
                return [self._miner_path, "-a", "kaspa", "-o", pool, "-u", w]

        elif self._coin == "etc":
            pool = ETC_POOLS[0]
            if "lolminer" in m:
                return [self._miner_path, "--algo", "ETCHASH", "--pool", pool, "--user", w]
            elif "gminer" in m:
                return [self._miner_path, "--algo", "etc", "--server", pool.split("//")[1].split(":")[0],
                        "--port", pool.split(":")[-1], "--user", w]
            else:
                return [self._miner_path, "-a", "etchash", "-o", pool, "-u", w]

        elif self._coin == "erg":
            pool = ERG_POOLS[0]
            return [self._miner_path, "-a", "autolykos2", "-o", pool, "-u", w]

        return None

    # ── Detection ─────────────────────────────────────────────────────────────

    @staticmethod
    def _find_miner() -> tuple[Optional[str], str]:
        """Шукаємо встановлені майнери у PATH і стандартних місцях."""
        candidates = [
            "bzminer", "gminer", "lolminer", "nbminer", "teamredminer",
            "srbminer-multi", "kaspa-miner", "rigel",
        ]
        # Стандартні шляхи
        extra_paths: list[Path] = []
        if SYS == "Windows":
            extra_paths += [
                Path("C:/miners"),
                Path(os.environ.get("USERPROFILE", "")) / "miners",
            ]
        else:
            extra_paths += [
                Path.home() / "miners",
                Path("/opt/miners"),
            ]

        for name in candidates:
            path = shutil.which(name)
            if path:
                return path, name
            for d in extra_paths:
                exe = d / (name + (".exe" if SYS == "Windows" else ""))
                if exe.exists():
                    return str(exe), name

        return None, ""

    @staticmethod
    def _choose_coin() -> str:
        if MINE_COIN != "auto":
            return MINE_COIN
        # За замовчуванням Kaspa — найкраща для NVIDIA у 2026
        return "kas"

    # ── JSON export for heartbeat ─────────────────────────────────────────────

    def heartbeat_data(self) -> dict:
        s = self.get_stats()
        return {
            "miner_active":      s.running,
            "miner_coin":        s.coin if s.running else "",
            "miner_hashrate":    s.hashrate_str if s.running else "",
            "miner_est_24h_usd": s.estimated_24h if s.running else 0.0,
        }
