"""
WireGuard network-level authentication для Node Agent.

Що робить:
  1. Завантажує/генерує WireGuard key pair (Curve25519)
  2. Підписує challenge від Gateway своїм SVIT Ed25519 ключем
  3. Отримує WireGuard config і застосовує його (`wg-quick`)
  4. Після цього нода в захищеній мережі Svitlo

Env:
  SVIT_PRIVATE_KEY   — Ed25519 private key (64-char hex = seed)
  WG_KEY_FILE        — шлях до файлу WireGuard private key (default: ~/.svitlo/wg.key)
  SVITLO_GATEWAY_URL — URL Gateway (default: https://gateway.svitlo.io)
  WG_CONFIG_FILE     — куди писати wg config (default: /etc/wireguard/svitlo0.conf)
"""
import base64
import logging
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger(__name__)

GATEWAY_URL    = os.environ.get("SVITLO_GATEWAY_URL", "https://gateway.svitlo.io")
WG_KEY_FILE    = Path(os.environ.get("WG_KEY_FILE", Path.home() / ".svitlo" / "wg.key"))
WG_CONFIG_FILE = Path(os.environ.get("WG_CONFIG_FILE", "/etc/wireguard/svitlo0.conf"))
SVIT_PRIV_KEY  = os.environ.get("SVIT_PRIVATE_KEY", "")


# ── WireGuard key management ──────────────────────────────────────────────────

def _generate_wg_keypair() -> tuple[str, str]:
    """Генерує WireGuard private + public key через `wg`."""
    priv = subprocess.check_output(["wg", "genkey"], text=True).strip()
    pub  = subprocess.check_output(["wg", "pubkey"], input=priv, text=True).strip()
    return priv, pub


def load_or_create_wg_keys() -> tuple[str, str]:
    """
    Завантажити існуючі WireGuard ключі або згенерувати нові.
    Повертає (private_key, public_key) у base64.
    """
    WG_KEY_FILE.parent.mkdir(parents=True, exist_ok=True)

    if WG_KEY_FILE.exists():
        priv = WG_KEY_FILE.read_text().strip()
        pub  = subprocess.check_output(["wg", "pubkey"], input=priv, text=True).strip()
        log.info("Loaded WireGuard key: pubkey=%.12s...", pub)
        return priv, pub

    priv, pub = _generate_wg_keypair()
    WG_KEY_FILE.write_text(priv)
    WG_KEY_FILE.chmod(0o600)
    log.info("Generated new WireGuard key: pubkey=%.12s...", pub)
    return priv, pub


# ── SVIT Ed25519 signing ──────────────────────────────────────────────────────

def _sign_message(message: str, private_key_hex: str) -> str:
    """
    Підписати повідомлення SVIT Ed25519 private key.
    private_key_hex — 64-char hex (32-byte seed).
    Повертає 128-char hex підпис.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    seed     = bytes.fromhex(private_key_hex)
    priv_key = Ed25519PrivateKey.from_private_bytes(seed)
    sig      = priv_key.sign(message.encode("utf-8"))
    return sig.hex()


def _get_wallet_address(private_key_hex: str) -> str:
    """Отримати SVIT wallet address (64-char hex Ed25519 pubkey) з private key."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    seed     = bytes.fromhex(private_key_hex)
    priv_key = Ed25519PrivateKey.from_private_bytes(seed)
    pub_bytes = priv_key.public_key().public_bytes_raw()
    return pub_bytes.hex()


# ── Auth flow ─────────────────────────────────────────────────────────────────

async def authenticate_and_connect() -> Optional[str]:
    """
    Повний flow WireGuard авторизації.
    Повертає assigned_ip якщо успішно, None якщо не вдалось.
    """
    if not SVIT_PRIV_KEY:
        log.warning("SVIT_PRIVATE_KEY not set — skipping WireGuard auth")
        return None

    wallet = _get_wallet_address(SVIT_PRIV_KEY)
    log.info("SVIT wallet: %s...%s", wallet[:8], wallet[-4:])

    try:
        wg_priv, wg_pub = load_or_create_wg_keys()
    except FileNotFoundError:
        log.warning("wg command not found — skipping WireGuard setup")
        return None

    async with httpx.AsyncClient(timeout=15.0) as client:
        # 1. Запросити challenge
        resp = await client.get(
            f"{GATEWAY_URL}/api/v1/auth/wg/challenge",
            params={"wallet": wallet, "wg_pubkey": wg_pub},
        )
        resp.raise_for_status()
        challenge = resp.json()
        nonce   = challenge["nonce"]
        message = challenge["message"]
        log.info("Got WG challenge nonce=%.8s...", nonce)

        # 2. Підписати challenge
        signature = _sign_message(message, SVIT_PRIV_KEY)

        # 3. Відправити підпис
        resp = await client.post(
            f"{GATEWAY_URL}/api/v1/auth/wg/verify",
            json={
                "wallet":    wallet,
                "wg_pubkey": wg_pub,
                "nonce":     nonce,
                "signature": signature,
            },
        )
        resp.raise_for_status()
        result = resp.json()

    if not result.get("authorized"):
        log.error("WireGuard auth denied: %s", result.get("message"))
        return None

    assigned_ip = result["assigned_ip"]
    wg_config   = result["wg_config"]

    # 4. Записати WireGuard config і підключитись
    _apply_wg_config(wg_priv, wg_config, assigned_ip)

    log.info("WireGuard connected. VPN IP: %s", assigned_ip)
    return assigned_ip


def _apply_wg_config(wg_priv: str, config_from_server: str, assigned_ip: str) -> None:
    """
    Записати повний WireGuard конфіг (з приватним ключем) і підключитись.
    """
    full_config = (
        "[Interface]\n"
        f"PrivateKey = {wg_priv}\n"
        f"Address = {assigned_ip}/32\n"
        "DNS = 10.8.0.1\n\n"
        + "\n".join(
            line for line in config_from_server.splitlines()
            if not line.startswith("[Interface]")
            and not line.startswith("Address")
            and not line.startswith("DNS")
            and not line.startswith("PrivateKey")
        )
    )

    WG_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    WG_CONFIG_FILE.write_text(full_config)
    WG_CONFIG_FILE.chmod(0o600)

    iface = WG_CONFIG_FILE.stem  # svitlo0
    try:
        # Якщо вже підключений — down спочатку
        subprocess.run(["wg-quick", "down", iface], capture_output=True)
    except Exception:
        pass

    subprocess.run(["wg-quick", "up", iface], check=True)
    log.info("wg-quick up %s — OK", iface)
