#!/usr/bin/env bash
# HiveOS custom-miner entry point -- HiveOS calls this to (re)start the
# "miner". Runs node_agent headless (same code path as run_linux.sh), no
# GUI/Tkinter/webview involved at all.
#
# NOT verified against a real HiveOS install -- see this directory's
# README.md. HiveOS flight-sheet fields map to env vars, but the exact
# names have shifted across HiveOS versions in their own docs/examples;
# this checks several plausible names and falls back to a plain config
# file so a wrong guess here doesn't hard-block setup.
set -euo pipefail
cd "$(dirname "$0")"

CONFIG_FILE="./svitlo.conf"   # fallback: hand-edit this file directly if the flight-sheet fields don't map the way this script expects

api_key="${CUSTOM_USER_CONFIG:-${CUSTOM_USER:-${CUSTOM_TEMPLATE:-}}}"
wallet="${CUSTOM_PASS:-${CUSTOM_PASSWORD:-}}"
platform_url="${CUSTOM_URL:-https://dares-suffering-swimwear.ngrok-free.dev}"
node_name="${WORKER_NAME:-$(hostname)}"

if [[ -f "$CONFIG_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$CONFIG_FILE"   # may set/override api_key, wallet, platform_url, node_name
fi

if [[ -z "${api_key:-}" || -z "${wallet:-}" ]]; then
    echo "svitlo-node-agent: missing API key or wallet." >&2
    echo "Either set the Flight Sheet's User/Config field to your API key and" >&2
    echo "Pass field to your 64-hex Svitlo Chain wallet, or edit $CONFIG_FILE directly:" >&2
    echo "  api_key=...\n  wallet=...\n  platform_url=https://...\n  node_name=rig-01" >&2
    exit 1
fi

if [[ ! "$wallet" =~ ^[0-9a-f]{64}$ ]]; then
    echo "svitlo-node-agent: wallet must be 64 lowercase hex chars — got: $wallet" >&2
    exit 1
fi

if [[ ! -d ".venv" ]]; then
    echo "svitlo-node-agent: first run — creating venv, installing deps..." >&2
    python3 -m venv .venv
    ./.venv/bin/pip install -q -r requirements.txt
fi

export SVITLO_API_KEY="$api_key"
export SVITLO_WALLET="$wallet"
export SVITLO_NODE_NAME="$node_name"
export SVITLO_PLATFORM_URL="$platform_url"
export SVITLO_POWER_MODE="manual"          # a mining rig is never "idle" in the owner-presence sense power_control.py detects
export SVITLO_POWER_PCT_MANUAL="${SVITLO_POWER_PCT_MANUAL:-90}"
export SVITLO_WG_AUTH="0"

exec ./.venv/bin/python3 agent.py
