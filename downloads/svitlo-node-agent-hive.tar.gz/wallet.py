"""
Svitlo Chain wallet — embedded creation/import for node_agent (2026-08-10).

Lets a provider create or import a real Svitlo Chain wallet directly inside
node_agent, instead of needing the separate mobile wallet app first just to
get a 64-hex address to register a node with. Byte-for-byte compatible with
the mobile wallet app's derivation (mobile/src/crypto/chain.ts):

    BIP39 mnemonic
      -> PBKDF2-HMAC-SHA512(password=mnemonic, salt="mnemonic", c=2048, dkLen=64)
      -> first 32 bytes = Ed25519 secret seed
      -> Ed25519 keypair
      -> address = hex(public key bytes), 64 lowercase hex chars

This is Svitlo Chain's own scheme (not standard BIP32/SLIP-0010), so a
wallet created here is recoverable in the mobile app with the same seed
phrase and vice versa -- one seed phrase, same address, either app.

Verified against mobile/src/crypto/__tests__/svit.test.ts's known vector
(mnemonic "abandon"x11 "about" -> address
c5785e1865b708938aff8161d573006496663b1aa10834e396dc566869a2c66a) --
see the __main__ self-test at the bottom of this file.

Non-custodial by construction: the mnemonic/private key never leaves this
process and is never sent to the platform backend. register() only ever
transmits the public 64-hex address.
"""
from __future__ import annotations

import json
import os
import stat

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from mnemonic import Mnemonic

_mnemo = Mnemonic("english")

WALLET_FILE = os.path.join(os.path.expanduser("~"), ".svitlo", "wallet.json")


def generate_mnemonic(words: int = 12) -> str:
    """12 words = 128 bits entropy, 24 words = 256 bits. 12 is the default
    everywhere else in this codebase (mobile app's generateMnemonic())."""
    strength = 256 if words == 24 else 128
    return _mnemo.generate(strength=strength)


def validate_mnemonic(phrase: str) -> bool:
    try:
        return _mnemo.check(_normalize(phrase))
    except Exception:
        return False


def _normalize(phrase: str) -> str:
    return " ".join(phrase.strip().split())


def derive_secret(mnemonic_phrase: str) -> bytes:
    """32-byte Ed25519 seed from a BIP39 mnemonic. Mnemonic.to_seed() uses
    PBKDF2-HMAC-SHA512(password=mnemonic, salt="mnemonic"+passphrase,
    c=2048, dkLen=64) with passphrase="" by default -- exactly matching
    chain.ts's deriveSvitSecret()."""
    seed64 = _mnemo.to_seed(_normalize(mnemonic_phrase))
    return seed64[:32]


def address_from_seed(secret: bytes) -> str:
    if len(secret) != 32:
        raise ValueError("seed must be exactly 32 bytes")
    priv = Ed25519PrivateKey.from_private_bytes(secret)
    pub = priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return pub.hex()


def address_from_seed_hex(seed_hex: str) -> str:
    """Import path for svitlo-wallet's raw 64-hex "export seed" (not a
    mnemonic) -- mirrors chain.ts's svitAddressFromSeedHex()."""
    clean = seed_hex.strip().lower()
    if len(clean) != 64:
        raise ValueError("seed must be 64 hex chars")
    return address_from_seed(bytes.fromhex(clean))


def derive_keypair(mnemonic_phrase: str) -> tuple[bytes, str]:
    """Returns (32-byte secret seed, 64-hex address)."""
    secret = derive_secret(mnemonic_phrase)
    return secret, address_from_seed(secret)


# ── Local storage ────────────────────────────────────────────────────────────
#
# Plaintext-on-disk, chmod 600, same trust model as node_agent's existing
# ~/.svitlo/config.env (API key, wallet address) -- this machine is already
# the trust boundary (it's running inference for money), and node_agent has
# no PIN/passphrase-entry UI to build real encryption-at-rest around yet.
# Flagged here rather than silently assumed: a real desktop keychain
# (macOS Keychain / Windows DPAPI / Linux Secret Service) would be a
# meaningfully better place for this and should replace plaintext storage
# before this is pointed at large balances.

def wallet_exists() -> bool:
    return os.path.exists(WALLET_FILE)


def save_wallet(mnemonic_phrase: str) -> str:
    """Persists the mnemonic locally and returns the derived address."""
    _, address = derive_keypair(mnemonic_phrase)
    os.makedirs(os.path.dirname(WALLET_FILE), exist_ok=True)
    with open(WALLET_FILE, "w") as f:
        json.dump({"mnemonic": _normalize(mnemonic_phrase), "address": address}, f)
    os.chmod(WALLET_FILE, stat.S_IRUSR | stat.S_IWUSR)  # 600
    return address


def load_wallet() -> dict | None:
    if not wallet_exists():
        return None
    with open(WALLET_FILE) as f:
        return json.load(f)


def create_new_wallet() -> tuple[str, str]:
    """Generates a brand-new wallet, saves it, returns (mnemonic, address)
    so the caller can show the mnemonic to the user exactly once."""
    phrase = generate_mnemonic()
    address = save_wallet(phrase)
    return phrase, address


def import_wallet(mnemonic_phrase: str) -> str:
    if not validate_mnemonic(mnemonic_phrase):
        raise ValueError("Invalid seed phrase — check spelling and word order")
    return save_wallet(mnemonic_phrase)


def _self_test() -> None:
    """Self-test against mobile/src/crypto/__tests__/svit.test.ts's known vector."""
    _TEST_MNEMONIC = "abandon " * 11 + "about"
    _EXPECTED = "c5785e1865b708938aff8161d573006496663b1aa10834e396dc566869a2c66a"
    _, addr = derive_keypair(_TEST_MNEMONIC.strip())
    assert addr == _EXPECTED, f"MISMATCH: got {addr}, expected {_EXPECTED}"
    print(f"OK — matches mobile app's derivation exactly: {addr}")


if __name__ == "__main__":
    # Tiny CLI, used by run_linux.sh (headless setup — no Tkinter there) so
    # the same create/import flow gui/app.py's SetupWizard offers is
    # available on a headless box too. `python3 wallet.py create` prints
    # {"mnemonic": ..., "address": ...} as JSON; `python3 wallet.py import`
    # reads the phrase from stdin and prints {"address": ...} (or exits 1
    # with an error on stderr for an invalid phrase). No args = self-test.
    import sys as _sys

    if len(_sys.argv) == 1:
        _self_test()
    elif _sys.argv[1] == "create":
        _phrase, _address = create_new_wallet()
        print(json.dumps({"mnemonic": _phrase, "address": _address}))
    elif _sys.argv[1] == "import":
        _phrase = _sys.stdin.read().strip()
        try:
            _address = import_wallet(_phrase)
        except ValueError as _e:
            print(json.dumps({"error": str(_e)}), file=_sys.stderr)
            _sys.exit(1)
        print(json.dumps({"address": _address}))
    else:
        print(f"Unknown command: {_sys.argv[1]}", file=_sys.stderr)
        _sys.exit(2)
