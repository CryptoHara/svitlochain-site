import hashlib
import json
from datetime import datetime, timezone


def generate_proof(job_id: str, node_id: str, prompt: str, output: str) -> tuple[str, str]:
    """Повертає (timestamp_iso, proof_hash)."""
    ts = datetime.now(timezone.utc).isoformat()
    payload = {
        "job_id": job_id,
        "node_id": node_id,
        "input_hash": hashlib.sha256(prompt.encode()).hexdigest(),
        "output_hash": hashlib.sha256(output.encode()).hexdigest(),
        "timestamp": ts,
    }
    canonical = json.dumps(payload, sort_keys=True)
    proof = hashlib.sha256(canonical.encode()).hexdigest()
    return ts, proof
