"""
Моніторинг ресурсів PC/сервера.
Підтримує: NVIDIA (pynvml), AMD (rocm-smi), CPU fallback.
"""
import subprocess
from dataclasses import dataclass, field
from typing import List, Optional

try:
    import pynvml
    _HAS_NVML = True
    pynvml.nvmlInit()
except Exception:
    _HAS_NVML = False

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    _HAS_PSUTIL = False


@dataclass
class GPUInfo:
    index: int
    name: str
    vram_total_gb: float
    vram_used_gb: float
    gpu_utilization: float      # 0.0–1.0
    temperature_c: Optional[float] = None


@dataclass
class SystemStats:
    gpus: List[GPUInfo] = field(default_factory=list)
    cpu_utilization: float = 0.0
    ram_total_gb: float = 0.0
    ram_used_gb: float = 0.0

    @property
    def primary_gpu_util(self) -> float:
        return self.gpus[0].gpu_utilization if self.gpus else 0.0

    @property
    def primary_vram_used(self) -> float:
        return self.gpus[0].vram_used_gb if self.gpus else 0.0

    @property
    def total_vram_gb(self) -> float:
        return sum(g.vram_total_gb for g in self.gpus)


def get_system_stats() -> SystemStats:
    stats = SystemStats()

    # CPU + RAM
    if _HAS_PSUTIL:
        stats.cpu_utilization = psutil.cpu_percent(interval=0.5) / 100.0
        mem = psutil.virtual_memory()
        stats.ram_total_gb = mem.total / 1e9
        stats.ram_used_gb = mem.used / 1e9

    # NVIDIA GPU
    if _HAS_NVML:
        try:
            count = pynvml.nvmlDeviceGetCount()
            for i in range(count):
                handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                name = pynvml.nvmlDeviceGetName(handle)
                if isinstance(name, bytes):
                    name = name.decode()
                mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                try:
                    temp = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
                except Exception:
                    temp = None

                stats.gpus.append(GPUInfo(
                    index=i,
                    name=name,
                    vram_total_gb=mem_info.total / 1e9,
                    vram_used_gb=mem_info.used / 1e9,
                    gpu_utilization=util.gpu / 100.0,
                    temperature_c=temp,
                ))
        except Exception:
            pass

    return stats


def get_gpu_specs() -> List[dict]:
    """Для реєстрації на платформі."""
    stats = get_system_stats()
    return [
        {
            "name": g.name,
            "vram_gb": round(g.vram_total_gb, 1),
        }
        for g in stats.gpus
    ]
