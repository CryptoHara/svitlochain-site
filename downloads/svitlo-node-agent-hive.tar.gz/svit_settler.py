"""
Svitlo Chain settler for physical GPU providers.

Two settlement paths:
  1. JobComplete (discriminant 6) — preferred, batch-capable.
     Handles 85/15 split, token refunds, and provider bonus natively on-chain.
     Used when job was funded via mobile JobSubmit TX (svit_job_id present).

  2. JobSettle (discriminant 2) — legacy single-job path.
     Miner gets (escrow - TX_FEE); no platform split.
     Kept for backward compatibility with older clients.

Wire format (bincode v1.3 — little-endian fixint, u32 enum discriminants):
  TxKind   — u32 LE discriminant + fields
  sender   — [u8; 32] Ed25519 pubkey (raw, no length prefix)
  nonce    — u64 LE
  timestamp— u64 LE
  sig      — u64 LE(64) + [u8; 64]   ← serialize_bytes encoding

Required env vars:
  SVITLO_NODE_URL    — e.g. http://192.168.1.108:8080
  SVITLO_MINER_KEY   — 64-char hex (32-byte Ed25519 seed) of the miner wallet
"""
from __future__ import annotations

import os
import struct
import time
from dataclasses import dataclass
from typing import Optional

import blake3
import httpx
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

# TxKind discriminants — MUST match Rust enum in types.rs exactly:
#   0=Transfer       1=JobSubmit      2=JobSettle
#   3=Stake          4=Unstake        5=PriceUpdate
#   6=JobComplete    7=InsuranceClaim 8=DistributedJobComplete
#   9=JobEscrow     10=ClaimStakingReward  11=Burn
_TX_KIND_JOB_SETTLE   = 2
_TX_KIND_JOB_COMPLETE = 6


@dataclass
class JobEntry:
    """One job in a JobComplete batch."""
    svit_job_id:  str    # 64-char hex (32-byte Blake3)
    output:      bytes  # raw inference output bytes (for commitment)
    latency_ms:  int
    tokens_used: int    # actual tokens consumed


class SvitSettler:
    def __init__(
        self,
        node_url:      Optional[str] = None,
        miner_key_hex: Optional[str] = None,
    ) -> None:
        self.node_url = (node_url or os.environ.get("SVITLO_NODE_URL", "")).rstrip("/")
        key_hex = miner_key_hex or os.environ.get("SVITLO_MINER_KEY", "")
        if not self.node_url or not key_hex:
            raise RuntimeError("SVITLO_NODE_URL and SVITLO_MINER_KEY must be set")

        self._priv = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(key_hex))
        self.miner_pub: bytes = self._priv.public_key().public_bytes_raw()  # 32 bytes

    @property
    def miner_address(self) -> str:
        return self.miner_pub.hex()

    # ── Nonce ─────────────────────────────────────────────────────────────────

    def _get_nonce(self) -> int:
        with httpx.Client(timeout=10.0) as http:
            r = http.get(f"{self.node_url}/balance/{self.miner_address}")
            r.raise_for_status()
        return r.json().get("nonce", 0)

    # ── Signing ───────────────────────────────────────────────────────────────

    def _sign_and_wrap(self, kind_bytes: bytes, nonce: int, timestamp: int) -> bytes:
        """Build signing payload, Blake3-hash it, Ed25519-sign, return full TX bytes."""
        payload  = kind_bytes + self.miner_pub
        payload += struct.pack("<Q", nonce)
        payload += struct.pack("<Q", timestamp)

        digest = blake3.blake3(payload).digest()
        sig    = self._priv.sign(digest)   # 64 bytes

        # Full Transaction: kind | sender | nonce | timestamp | u64(64) | sig
        tx  = kind_bytes + self.miner_pub
        tx += struct.pack("<Q", nonce)
        tx += struct.pack("<Q", timestamp)
        tx += struct.pack("<Q", 64)        # Sig serialized as serialize_bytes → u64 len prefix
        tx += sig
        return tx

    # ── JobComplete (discriminant 6) ──────────────────────────────────────────

    def _encode_job_complete(self, jobs: list[JobEntry]) -> bytes:
        """
        Encode TxKind::JobComplete in bincode v1.3 format.

        JobComplete {
            job_ids:     Vec<[u8; 32]>,   — u64 LE(n) + n × 32 bytes
            commitments: Vec<[u8; 16]>,   — u64 LE(n) + n × 16 bytes
            latencies:   Vec<u32>,         — u64 LE(n) + n × u32 LE
            proof_hash:  [u8; 32],         — 32 bytes raw (fixed array, no length)
            tokens_used: Vec<u32>,         — u64 LE(n) + n × u32 LE
        }
        """
        n = len(jobs)
        job_ids     = [bytes.fromhex(j.svit_job_id) for j in jobs]
        commitments = [blake3.blake3(j.output).digest()[:16] for j in jobs]

        # proof_hash = Blake3(concat(job_ids) || concat(commitments))
        hasher = blake3.blake3()
        for jid in job_ids:     hasher.update(jid)
        for cm  in commitments: hasher.update(cm)
        proof_hash = hasher.digest()  # 32 bytes

        kind  = struct.pack("<I", _TX_KIND_JOB_COMPLETE)
        kind += struct.pack("<Q", n)
        for jid in job_ids:     kind += jid
        kind += struct.pack("<Q", n)
        for cm in commitments:  kind += cm
        kind += struct.pack("<Q", n)
        for j in jobs:          kind += struct.pack("<I", j.latency_ms)
        kind += proof_hash                              # fixed [u8;32] — no length prefix
        kind += struct.pack("<Q", n)
        for j in jobs:          kind += struct.pack("<I", min(j.tokens_used, 0xFFFFFFFF))
        return kind

    def complete_jobs_batch(self, jobs: list[JobEntry]) -> dict:
        """
        Submit a JobComplete TX settling one or more inference jobs.
        Returns {"ok": true, "tx_hash": "..."} or {"ok": false, "error": "..."}.

        Chain effect: 85% to miner, 15% to platform fee pool, unused-token refund to submitter.
        """
        if not jobs:
            return {"ok": False, "error": "empty job list"}

        kind_bytes = self._encode_job_complete(jobs)
        nonce      = self._get_nonce()
        timestamp  = int(time.time() * 1000)
        tx         = self._sign_and_wrap(kind_bytes, nonce, timestamp)

        with httpx.Client(timeout=15.0) as http:
            resp = http.post(f"{self.node_url}/tx", json={"tx_hex": tx.hex()})
        return resp.json()

    # ── JobSettle (discriminant 2) — legacy single-job path ──────────────────

    def _encode_job_settle(
        self,
        job_id:     bytes,   # 32 bytes
        commitment: bytes,   # 16 bytes
        latency_ms: int,
    ) -> bytes:
        kind  = struct.pack("<I", _TX_KIND_JOB_SETTLE)
        kind += job_id + commitment + struct.pack("<I", latency_ms)
        return kind

    def settle_job(
        self,
        svit_job_id:  str,           # 64-char hex
        output:      str | bytes,   # model output — for commitment derivation
        latency_ms:  int,
    ) -> dict:
        """Legacy single-job settlement (no platform split). Use complete_jobs_batch() instead."""
        job_id_bytes = bytes.fromhex(svit_job_id)
        if isinstance(output, str):
            output = output.encode()
        commitment = blake3.blake3(output).digest()[:16]

        kind_bytes = self._encode_job_settle(job_id_bytes, commitment, latency_ms)
        nonce      = self._get_nonce()
        timestamp  = int(time.time() * 1000)
        tx         = self._sign_and_wrap(kind_bytes, nonce, timestamp)

        with httpx.Client(timeout=15.0) as http:
            resp = http.post(f"{self.node_url}/tx", json={"tx_hex": tx.hex()})
        return resp.json()

    def is_configured(self) -> bool:
        return bool(self.node_url and self.miner_pub)


# ── Convenience wrappers ───────────────────────────────────────────────────────

def try_complete_batch(
    jobs:       list[JobEntry],
    node_url:   Optional[str] = None,
    key_hex:    Optional[str] = None,
) -> Optional[dict]:
    """
    Submit a JobComplete TX for one or more jobs. Returns None if SVIT not configured.
    Use this after any inference job that has a svit_job_id.
    """
    _url = node_url or os.environ.get("SVITLO_NODE_URL", "")
    _key = key_hex  or os.environ.get("SVITLO_MINER_KEY", "")
    if not _url or not _key or not jobs:
        return None
    try:
        settler = SvitSettler(_url, _key)
        result  = settler.complete_jobs_batch(jobs)
        return result
    except Exception as exc:
        print(f"⚠️  SVIT JobComplete failed: {exc}")
        return None


def try_settle(
    svit_job_id: Optional[str],
    output:     str | bytes,
    latency_ms: int,
    node_url:   Optional[str] = None,
    key_hex:    Optional[str] = None,
) -> Optional[dict]:
    """
    Legacy convenience wrapper for single-job JobSettle.
    Prefer try_complete_batch() for new code.
    """
    if not svit_job_id:
        return None
    _url = node_url or os.environ.get("SVITLO_NODE_URL", "")
    _key = key_hex  or os.environ.get("SVITLO_MINER_KEY", "")
    if not _url or not _key:
        return None
    try:
        settler = SvitSettler(_url, _key)
        result  = settler.settle_job(svit_job_id, output, latency_ms)
        return result
    except Exception as exc:
        print(f"⚠️  SVIT JobSettle failed: {exc}")
        return None
