#!/usr/bin/env bash
# Svitlo Node Agent — headless Linux launcher (no GUI/Tkinter needed).
#
# agent.py is plain, portable Python -- gui/app.py is only a Tkinter wrapper
# around it, not a hard dependency. This is the natural way to run a
# provider node on a Linux box (server or desktop), and how a multi-machine
# fleet (several PCs, same account, different node names) is expected to
# work today: run this script once per machine.
#
# First run asks for API key / wallet / node name and saves them to
# ~/.svitlo/config.env; later runs just reuse that file. Re-run with
# `--reconfigure` to change saved values.
set -euo pipefail
cd "$(dirname "$0")"

CONFIG_DIR="$HOME/.svitlo"
CONFIG_FILE="$CONFIG_DIR/config.env"
mkdir -p "$CONFIG_DIR"

# api.svitlochain.com has no DNS record yet (2026-08-09) -- real reachable
# endpoint is the platform backend behind svitlo-edge-proxy, sharing
# genesis2's ngrok tunnel. Update this once a permanent domain is live.
PLATFORM_URL_DEFAULT="https://dares-suffering-swimwear.ngrok-free.dev"

if [[ "${1:-}" == "--reconfigure" ]]; then
    rm -f "$CONFIG_FILE"
fi

# venv + deps come first now (2026-08-10) -- the wallet create/import menu
# below shells out to `python3 wallet.py`, which needs cryptography +
# mnemonic installed, so first-run config can't happen before this anymore.
if [[ ! -d ".venv" ]]; then
    echo "Creating virtualenv..."
    python3 -m venv .venv
fi
source .venv/bin/activate
pip install -q -r requirements.txt

if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "=== Svitlo Node Agent — first-time setup on $(hostname) ==="
    read -rp "API Key (from svitlochain.com/dashboard): " api_key

    echo
    echo "Svitlo Chain Wallet (SVIT earnings):"
    echo "  1) I already have an address"
    echo "  2) Create a new wallet here"
    echo "  3) Import an existing wallet via seed phrase"
    read -rp "Choice [1]: " wallet_choice
    wallet_choice="${wallet_choice:-1}"

    case "$wallet_choice" in
        2)
            result="$(python3 wallet.py create)"
            wallet="$(echo "$result" | python3 -c 'import json,sys; print(json.load(sys.stdin)["address"])')"
            phrase="$(echo "$result" | python3 -c 'import json,sys; print(json.load(sys.stdin)["mnemonic"])')"
            echo
            echo "⚠️  WRITE THIS DOWN — it is the only way to recover this wallet. Shown once:"
            echo
            echo "  $phrase"
            echo
            echo "Address: $wallet"
            read -rp "Press Enter once you've saved it somewhere safe... " _ack
            ;;
        3)
            echo "Paste your 12 or 24-word seed phrase, then press Enter:"
            read -r phrase
            if ! result="$(printf '%s' "$phrase" | python3 wallet.py import)"; then
                echo "Invalid seed phrase — check spelling and word order." >&2
                exit 1
            fi
            wallet="$(echo "$result" | python3 -c 'import json,sys; print(json.load(sys.stdin)["address"])')"
            unset phrase
            echo "Imported. Address: $wallet"
            ;;
        *)
            while true; do
                read -rp "Svitlo Chain Wallet (64 hex chars): " wallet
                wallet="$(echo "$wallet" | tr '[:upper:]' '[:lower:]')"
                if [[ "$wallet" =~ ^[0-9a-f]{64}$ ]]; then break; fi
                echo "  Must be exactly 64 hex characters — try again."
            done
            ;;
    esac

    read -rp "Node name [default: $(hostname)-$(date +%s | tail -c 5)]: " node_name
    node_name="${node_name:-$(hostname)-$(date +%s | tail -c 5)}"
    read -rp "Platform URL [default: $PLATFORM_URL_DEFAULT]: " platform_url
    platform_url="${platform_url:-$PLATFORM_URL_DEFAULT}"

    cat > "$CONFIG_FILE" <<EOF
SVITLO_API_KEY=$api_key
SVITLO_WALLET=$wallet
SVITLO_NODE_NAME=$node_name
SVITLO_PLATFORM_URL=$platform_url
SVITLO_POWER_MODE=auto
SVITLO_POWER_PCT_MANUAL=70
SVITLO_POWER_PCT_IDLE=85
SVITLO_POWER_PCT_ACTIVE=45
SVITLO_WG_AUTH=0
EOF
    chmod 600 "$CONFIG_FILE"
    echo "Saved to $CONFIG_FILE (re-run with --reconfigure to change)."
fi

set -a
# shellcheck disable=SC1090
source "$CONFIG_FILE"
set +a

echo "Starting Svitlo Node Agent (node: $SVITLO_NODE_NAME, platform: $SVITLO_PLATFORM_URL)..."
exec python3 agent.py
