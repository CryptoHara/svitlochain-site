"""
Power control — how much of this PC's compute the owner shares with the
network, and the automatic idle/active throttle.

Modes:
  manual — always share power_pct_manual (10-100%).
  auto   — share power_pct_idle (default 85%) while the owner isn't touching
           the machine, drop to power_pct_active (default 45%) the moment
           they start using it again. This is the recommended default: the
           node contributes heavily when the PC would otherwise sit idle,
           and gets out of the owner's way during real use.

Idle detection is OS-native (seconds since last keyboard/mouse input), not a
CPU-usage heuristic — a busy background process on the owner's machine
shouldn't be mistaken for "owner is using it", and a video call sitting
mostly idle at the input level shouldn't be mistaken for "PC is free" either
(both are true failure modes of CPU-based heuristics). If idle time can't be
determined on this OS/environment, we fail toward the SAFE default (treat as
active / low share) rather than assuming the PC is free.
"""
import os
import platform
import subprocess
from dataclasses import dataclass

IDLE_THRESHOLD_S = 120  # 2 minutes with no input -> "PC is free"

DEFAULT_POWER_PCT_IDLE = 85
DEFAULT_POWER_PCT_ACTIVE = 45
DEFAULT_POWER_PCT_MANUAL = 70

_MIN_THREADS = 1


@dataclass
class PowerConfig:
    mode: str = "auto"                                    # "auto" | "manual"
    pct_manual: int = DEFAULT_POWER_PCT_MANUAL
    pct_idle: int = DEFAULT_POWER_PCT_IDLE
    pct_active: int = DEFAULT_POWER_PCT_ACTIVE

    @classmethod
    def from_dict(cls, d: dict) -> "PowerConfig":
        return cls(
            mode=d.get("power_mode", "auto") if d.get("power_mode") in ("auto", "manual") else "auto",
            pct_manual=_clamp_pct(d.get("power_pct_manual", DEFAULT_POWER_PCT_MANUAL)),
            pct_idle=_clamp_pct(d.get("power_pct_idle", DEFAULT_POWER_PCT_IDLE)),
            pct_active=_clamp_pct(d.get("power_pct_active", DEFAULT_POWER_PCT_ACTIVE)),
        )


def _clamp_pct(pct) -> int:
    try:
        pct = int(pct)
    except (TypeError, ValueError):
        return DEFAULT_POWER_PCT_MANUAL
    return max(10, min(100, pct))


def idle_seconds() -> float:
    """Seconds since the last keyboard/mouse input, or 0.0 (== 'active') if
    this OS/environment doesn't support idle detection -- fails safe."""
    system = platform.system()
    try:
        if system == "Darwin":
            return _idle_seconds_macos()
        if system == "Windows":
            return _idle_seconds_windows()
        if system == "Linux":
            return _idle_seconds_linux()
    except Exception:
        pass
    return 0.0


def _idle_seconds_macos() -> float:
    # ioreg reports HIDIdleTime in nanoseconds since last HID event.
    out = subprocess.check_output(
        ["ioreg", "-c", "IOHIDSystem"], timeout=3, stderr=subprocess.DEVNULL
    ).decode(errors="ignore")
    for line in out.splitlines():
        if "HIDIdleTime" in line:
            digits = "".join(ch for ch in line.split("=")[-1] if ch.isdigit())
            if digits:
                return int(digits) / 1_000_000_000.0
    return 0.0


def _idle_seconds_windows() -> float:
    import ctypes

    class LASTINPUTINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]

    info = LASTINPUTINFO()
    info.cbSize = ctypes.sizeof(LASTINPUTINFO)
    if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
        return 0.0
    millis_idle = ctypes.windll.kernel32.GetTickCount() - info.dwTime
    return max(0.0, millis_idle / 1000.0)


def _idle_seconds_linux() -> float:
    # xprintidle (X11) reports idle time in milliseconds. Not installed by
    # default on most distros and there's no reliable Wayland equivalent
    # without compositor-specific protocols -- if it's missing, fail safe
    # (treat as active) rather than guess.
    out = subprocess.check_output(["xprintidle"], timeout=3, stderr=subprocess.DEVNULL)
    return int(out.decode().strip()) / 1000.0


def effective_power_pct(cfg: PowerConfig) -> int:
    if cfg.mode == "manual":
        return cfg.pct_manual
    is_idle = idle_seconds() >= IDLE_THRESHOLD_S
    return cfg.pct_idle if is_idle else cfg.pct_active


def threads_for_pct(pct: int, total_cpus: int = None) -> int:
    """Scale available CPU threads by the target percentage."""
    total = total_cpus or os.cpu_count() or 4
    return max(_MIN_THREADS, round(total * pct / 100))


def apply_process_niceness(pct: int) -> None:
    """Lower this process's OS scheduling priority proportionally to how
    little power we're sharing, so foreground apps win contention even if
    our own thread-count throttle isn't perfectly effective. Best-effort --
    insufficient permissions or an unsupported platform are silently
    ignored, never fatal."""
    try:
        import psutil
        p = psutil.Process()
        if platform.system() == "Windows":
            # Coarse 3-tier mapping onto Windows priority classes.
            if pct >= 80:
                p.nice(psutil.NORMAL_PRIORITY_CLASS)
            elif pct >= 50:
                p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
            else:
                p.nice(psutil.IDLE_PRIORITY_CLASS)
        else:
            # POSIX nice range is -20 (highest) .. 19 (lowest). Map 100% -> 0
            # (leave default priority alone), 10% -> 19 (fully back off).
            p.nice(round((100 - pct) / 100 * 19))
    except Exception:
        pass
