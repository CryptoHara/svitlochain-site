"""
Inference worker — запускає LLM inference через llama-cpp-python.

Підтримувані бекенди:
  1. llama-cpp-python  (GGUF моделі, CPU + CUDA)
  2. vLLM             (через subprocess/API, для великих GPU)
  3. Mock             (тестування без GPU)
"""
import time
import os
from dataclasses import dataclass
from typing import Optional

from power_control import PowerConfig, apply_process_niceness, effective_power_pct, threads_for_pct


def _power_config_from_env() -> PowerConfig:
    return PowerConfig.from_dict({
        "power_mode":       os.environ.get("SVITLO_POWER_MODE", "auto"),
        "power_pct_manual": os.environ.get("SVITLO_POWER_PCT_MANUAL", 70),
        "power_pct_idle":   os.environ.get("SVITLO_POWER_PCT_IDLE", 85),
        "power_pct_active": os.environ.get("SVITLO_POWER_PCT_ACTIVE", 45),
    })


@dataclass
class InferenceResult:
    output: str
    tokens_prompt: int
    tokens_completion: int
    latency_ms: int


# Реєстр завантажених моделей (lazy loading)
_loaded_models: dict = {}

# Шлях до папки з GGUF моделями
MODELS_DIR = os.environ.get("SVITLO_MODELS_DIR", os.path.expanduser("~/svitlo_models"))

MODEL_FILES = {
    "llama3-8b":         "Meta-Llama-3-8B-Instruct.Q4_K_M.gguf",
    "mistral-7b":        "Mistral-7B-Instruct-v0.3.Q4_K_M.gguf",
    "phi-3-mini":        "Phi-3-mini-4k-instruct-q4.gguf",
    "gemma-7b":          "gemma-7b-it-Q4_K_M.gguf",
    "codellama-13b":     "CodeLlama-13b-Instruct.Q4_K_M.gguf",
    "deepseek-coder-6.7b": "deepseek-coder-6.7b-instruct.Q4_K_M.gguf",
}


def _load_model(model_name: str):
    """Lazy-load GGUF модель в пам'ять."""
    if model_name in _loaded_models:
        return _loaded_models[model_name]

    model_file = MODEL_FILES.get(model_name)
    if not model_file:
        raise ValueError(f"Unknown model: {model_name}")

    model_path = os.path.join(MODELS_DIR, model_file)
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")

    try:
        from llama_cpp import Llama
        # n_threads is fixed for this model's lifetime (llama-cpp-python has no
        # reliable per-call override) -- sized to the IDLE ceiling (the most
        # threads we'd ever want), since the active/idle *dynamic* throttle is
        # handled per-call via apply_process_niceness() instead. See
        # power_control.py's module doc for why.
        power_cfg = _power_config_from_env()
        n_threads = threads_for_pct(power_cfg.pct_idle)
        llm = Llama(
            model_path=model_path,
            n_ctx=4096,
            n_gpu_layers=-1,    # -1 = все на GPU якщо є CUDA
            n_threads=n_threads,
            verbose=False,
        )
        _loaded_models[model_name] = llm
        return llm
    except ImportError:
        raise RuntimeError("llama-cpp-python not installed. Run: pip install llama-cpp-python")


def run_inference(
    model_name: str,
    prompt: str,
    max_tokens: int = 512,
    temperature: float = 0.7,
    system_prompt: Optional[str] = None,
) -> InferenceResult:
    """
    Запускає inference.
    При відсутності GPU або моделі — повертає mock результат.
    """
    t0 = time.time()

    # Dynamic idle/active throttle -- re-evaluated on every job since the
    # owner's activity can change between requests. n_threads was fixed at
    # model-load time (see _load_model), so this is the real-time lever.
    power_cfg = _power_config_from_env()
    apply_process_niceness(effective_power_pct(power_cfg))

    try:
        llm = _load_model(model_name)
    except (FileNotFoundError, RuntimeError, ValueError):
        # Mock для розробки/тестування
        return _mock_inference(prompt, max_tokens, t0)

    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    response = llm.create_chat_completion(
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature,
        stream=False,
    )

    latency_ms = int((time.time() - t0) * 1000)
    choice = response["choices"][0]
    usage = response.get("usage", {})

    return InferenceResult(
        output=choice["message"]["content"],
        tokens_prompt=usage.get("prompt_tokens", len(prompt.split())),
        tokens_completion=usage.get("completion_tokens", max_tokens // 2),
        latency_ms=latency_ms,
    )


def _mock_inference(prompt: str, max_tokens: int, t0: float) -> InferenceResult:
    """Mock відповідь для тестування без GPU."""
    time.sleep(0.1)
    output = f"[MOCK] I received your prompt: '{prompt[:50]}...' This is a simulated response for testing."
    return InferenceResult(
        output=output,
        tokens_prompt=len(prompt.split()),
        tokens_completion=len(output.split()),
        latency_ms=int((time.time() - t0) * 1000),
    )
