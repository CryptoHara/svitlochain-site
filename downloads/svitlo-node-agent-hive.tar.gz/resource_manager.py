"""
Svitlo Resource Manager — динамічний розподіл ресурсів ПК.

Логіка:
  Користувач активний (idle < 2 хв)  → CPU 40%, GPU priority LOW
  Користувач відсутній (idle ≥ 2 хв) → CPU 60%, GPU priority NORMAL
  Режим standby (система засинає)     → зберегти стан, listen для wake-up job

CPU throttle реалізований через обмеження кількості потоків що передаються
в inference worker (--threads N). Не потребує root/admin.

Підтримка: Windows, Linux (X11 + без GUI), macOS
"""
import os
import platform
import subprocess
import threading
import time
from dataclasses import dataclass, field
from typing import Optional, Callable


# ── Поріг idle ─────────────────────────────────────────────────────────────────

IDLE_THRESHOLD_S: float = float(os.environ.get("SVITLO_IDLE_THRESHOLD_S", "120"))   # 2 хв
POLL_INTERVAL_S:  float = float(os.environ.get("SVITLO_RESOURCE_POLL_S", "30"))
ACTIVE_CPU_PCT:   float = float(os.environ.get("SVITLO_ACTIVE_CPU_PCT", "0.40"))    # 40% якщо юзер активний
IDLE_CPU_PCT:     float = float(os.environ.get("SVITLO_IDLE_CPU_PCT", "0.60"))      # 60% якщо idle


@dataclass
class ResourceState:
    user_present:           bool  = False
    cpu_throttle_pct:       float = IDLE_CPU_PCT
    cpu_threads_available:  int   = 0
    idle_seconds:           float = 0.0
    total_cpu_cores:        int   = 0


# ── Cross-platform idle time ────────────────────────────────────────────────────

def _get_idle_seconds() -> float:
    """Скільки секунд пройшло з останнього введення користувача."""
    sys = platform.system()

    if sys == "Windows":
        return _idle_windows()
    elif sys == "Linux":
        return _idle_linux()
    elif sys == "Darwin":
        return _idle_macos()

    return 0.0  # невідома ОС → вважати активним


def _idle_windows() -> float:
    try:
        import ctypes
        from ctypes import Structure, c_uint, sizeof, byref

        class LASTINPUTINFO(Structure):
            _fields_ = [("cbSize", c_uint), ("dwTime", c_uint)]

        lii = LASTINPUTINFO()
        lii.cbSize = sizeof(LASTINPUTINFO)
        ctypes.windll.user32.GetLastInputInfo(byref(lii))
        ms = ctypes.windll.kernel32.GetTickCount() - lii.dwTime
        return max(0.0, ms / 1000.0)
    except Exception:
        return 0.0


def _idle_linux() -> float:
    # Спроба 1: xprintidle (X11 session)
    try:
        result = subprocess.run(
            ["xprintidle"],
            capture_output=True, text=True, timeout=2,
        )
        if result.returncode == 0 and result.stdout.strip().isdigit():
            return int(result.stdout.strip()) / 1000.0
    except FileNotFoundError:
        pass
    except Exception:
        pass

    # Спроба 2: gdbus (GNOME Mutter idle monitor)
    try:
        result = subprocess.run(
            [
                "gdbus", "call", "--session",
                "--dest", "org.gnome.Mutter.IdleMonitor",
                "--object-path", "/org/gnome/Mutter/IdleMonitor/Core",
                "--method", "org.gnome.Mutter.IdleMonitor.GetIdletime",
            ],
            capture_output=True, text=True, timeout=2,
        )
        if result.returncode == 0:
            ms = int(result.stdout.strip().strip("()").strip(","))
            return ms / 1000.0
    except Exception:
        pass

    # Без GUI (сервер/headless) → вважати idle завжди
    return IDLE_THRESHOLD_S + 1.0


def _idle_macos() -> float:
    try:
        result = subprocess.run(
            ["ioreg", "-c", "IOHIDSystem"],
            capture_output=True, text=True, timeout=3,
        )
        for line in result.stdout.splitlines():
            if "HIDIdleTime" in line:
                ns = int(line.split("=")[-1].strip())
                return ns / 1_000_000_000.0
    except Exception:
        pass
    return 0.0


# ── CPU thread calculation ──────────────────────────────────────────────────────

def _calc_threads(total_cores: int, throttle_pct: float) -> int:
    """Скільки потоків доступно для inference."""
    # Завжди залишати мінімум 2 ядра вільними для ОС
    usable = max(1, total_cores - 2)
    threads = max(1, int(usable * throttle_pct))
    return threads


# ── ResourceManager ─────────────────────────────────────────────────────────────

class ResourceManager:
    """
    Фоновий thread що стежить за активністю користувача і керує
    кількістю потоків для inference.

    Використання:
        rm = ResourceManager()
        rm.start()
        ...
        state = rm.get_state()
        inference_worker.set_threads(state.cpu_threads_available)
        ...
        rm.stop()
    """

    def __init__(
        self,
        on_state_change: Optional[Callable[[ResourceState], None]] = None,
    ):
        self._total_cores = os.cpu_count() or 4
        self._state = ResourceState(
            total_cpu_cores=self._total_cores,
            cpu_threads_available=_calc_threads(self._total_cores, IDLE_CPU_PCT),
        )
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._on_change = on_state_change

    def start(self) -> None:
        self._thread = threading.Thread(target=self._loop, daemon=True, name="resource-manager")
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)

    def get_state(self) -> ResourceState:
        with self._lock:
            # повертаємо копію
            s = self._state
            return ResourceState(
                user_present=s.user_present,
                cpu_throttle_pct=s.cpu_throttle_pct,
                cpu_threads_available=s.cpu_threads_available,
                idle_seconds=s.idle_seconds,
                total_cpu_cores=s.total_cpu_cores,
            )

    def _loop(self) -> None:
        prev_present: Optional[bool] = None

        while not self._stop_event.is_set():
            idle = _get_idle_seconds()
            present = idle < IDLE_THRESHOLD_S
            throttle = ACTIVE_CPU_PCT if present else IDLE_CPU_PCT
            threads = _calc_threads(self._total_cores, throttle)

            new_state = ResourceState(
                user_present=present,
                cpu_throttle_pct=throttle,
                cpu_threads_available=threads,
                idle_seconds=idle,
                total_cpu_cores=self._total_cores,
            )

            changed = (prev_present is None) or (prev_present != present)
            with self._lock:
                self._state = new_state

            if changed:
                prev_present = present
                label = "ACTIVE (40% CPU)" if present else "IDLE (60% CPU)"
                print(f"[ResourceManager] User {'present' if present else 'away'} → {label}, threads={threads}")
                if self._on_change:
                    try:
                        self._on_change(new_state)
                    except Exception:
                        pass

            self._stop_event.wait(timeout=POLL_INTERVAL_S)


# ── Standby / Wake-up handler ───────────────────────────────────────────────────

class StandbyManager:
    """
    Слухає HTTP-пінг від платформи коли ПК в сплячому режимі.
    Коли є job → будить основний agent (subprocess).

    Запускається як окремий легкий процес через інсталятор:
      python -m resource_manager --standby-only

    Платформа пінгує: GET http://node-ip:8002/wakeup
    """

    def __init__(self, wake_callback: Optional[Callable] = None, port: int = 8002):
        self._port = port
        self._wake_callback = wake_callback

    def listen(self) -> None:
        """Blocking: запускає мінімальний HTTP-сервер для wake-up сигналів."""
        import http.server

        manager = self

        class WakeHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path.startswith("/wakeup"):
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"waking up")
                    if manager._wake_callback:
                        threading.Thread(
                            target=manager._wake_callback, daemon=True
                        ).start()
                else:
                    self.send_response(404)
                    self.end_headers()

            def log_message(self, *args):
                pass  # silent

        with http.server.HTTPServer(("0.0.0.0", self._port), WakeHandler) as srv:
            print(f"[StandbyManager] Listening for wake-up on port {self._port}")
            srv.serve_forever()


# ── CLI entry point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    if "--standby-only" in sys.argv:
        def _on_wakeup():
            print("[StandbyManager] Wake signal received — launching agent...")
            subprocess.Popen(
                [sys.executable, "agent.py"],
                cwd=os.path.dirname(os.path.abspath(__file__)),
            )

        sm = StandbyManager(wake_callback=_on_wakeup)
        sm.listen()
    else:
        rm = ResourceManager(on_state_change=lambda s: print(
            f"  threads={s.cpu_threads_available}, idle={s.idle_seconds:.0f}s"
        ))
        rm.start()
        print(f"[ResourceManager] Monitoring on {os.cpu_count()} cores. Ctrl+C to stop.")
        try:
            while True:
                time.sleep(5)
                state = rm.get_state()
                print(
                    f"  user_present={state.user_present}  "
                    f"cpu_throttle={state.cpu_throttle_pct:.0%}  "
                    f"threads={state.cpu_threads_available}/{state.total_cpu_cores}  "
                    f"idle={state.idle_seconds:.0f}s"
                )
        except KeyboardInterrupt:
            rm.stop()
