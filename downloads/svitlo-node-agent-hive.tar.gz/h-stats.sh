#!/usr/bin/env bash
# HiveOS polls this periodically for fleet-dashboard stats. Must print one
# JSON object to stdout.
#
# NOT verified against a real HiveOS install -- the exact field set HiveOS's
# dashboard expects has shifted across versions in their own docs; this is
# a best-effort match to the commonly documented shape. "hs" (normally
# hashrate) carries tokens/sec instead, clearly labeled via hs_units --
# there is no real hashrate here, this node serves AI inference, not PoW.
# See this directory's README.md.
set -euo pipefail
cd "$(dirname "$0")"

if [[ ! -x .venv/bin/python3 ]]; then
    echo '{"error":"not set up yet — run h-run.sh first"}'
    exit 0
fi

./.venv/bin/python3 - <<'PYEOF'
import json
import sys
import time

try:
    from gpu_monitor import get_system_stats
    stats = get_system_stats()
    temps = [g.temperature_c for g in stats.gpus if g.temperature_c is not None]
    gpu_util_pct = round(stats.primary_gpu_util * 100, 1)
except Exception:
    temps = []
    gpu_util_pct = 0.0

try:
    from stats_tracker import get_totals, get_hourly_series
    totals = get_totals()
    last_hour = get_hourly_series(hours=1)[-1]
    tokens_per_sec = round(last_hour["bytes_transferred"] / 3600.0, 2)  # rough proxy, see README
except Exception:
    totals = {"jobs_total": 0, "tokens_total": 0, "earnings_usd_total": 0.0}
    tokens_per_sec = 0.0

out = {
    "hs": [tokens_per_sec],
    "hs_units": "tok/s",
    "temp": temps,
    "fan": [],
    "uptime": int(time.time()),
    "ver": "1.0.0",
    "ar": [totals["jobs_total"], 0],  # [jobs completed, jobs failed] -- reusing HiveOS's accepted/rejected slot
    "algo": "ai-inference",
    "gpu_util_pct": gpu_util_pct,
    "earnings_usd_total_est": round(totals.get("earnings_usd_total", 0.0), 6),
}
print(json.dumps(out))
PYEOF
