"""
Stats tracker — records real per-job traffic and "rented hours" (time spent
actually serving inference) to a local rolling history file, so the GUI has
genuine data to chart instead of the static placeholders it showed before.

File-based rather than in-memory/IPC: agent.py's HTTP server and the GUI run
in different threads of the same process (see gui/app.py's
_start_agent_thread), but the GUI polls this file on its own 3s timer the
same way it already reads config.json -- no new cross-thread synchronization
primitive needed, consistent with the existing pattern.
"""
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

STATS_PATH = Path.home() / ".svitlo" / "stats_history.json"
MAX_ENTRIES = 5000  # ~ a couple months at one entry per completed job for a busy node


@dataclass
class JobStatEntry:
    ts_ms: int
    tokens: int
    bytes_transferred: int
    duration_s: float


def record_job(tokens: int, bytes_transferred: int, duration_s: float, earnings_usd: float = 0.0) -> None:
    """Append one completed job's stats. Best-effort -- a stats-file hiccup
    must never break real job serving.

    earnings_usd (added 2026-08-10, for the webview dashboard's "funds
    turnover" stat): tokens * this node's own advertised price_per_token --
    the same estimate agent.py already has on hand at record time. This is
    a LOCAL estimate of gross revenue, not the authoritative settled
    figure -- the real payout (after platform commission) is recorded
    server-side in node_earnings.earned_svit (see backend/core/
    fleet_manager.py). Showing it as "estimated" in the UI, not "balance",
    keeps that distinction honest without needing a new authenticated
    node-facing earnings endpoint (doesn't exist yet outside the
    enterprise/fleet routes)."""
    try:
        STATS_PATH.parent.mkdir(parents=True, exist_ok=True)
        history = _load_raw()
        history.append({
            "ts_ms": int(time.time() * 1000),
            "tokens": tokens,
            "bytes_transferred": bytes_transferred,
            "duration_s": duration_s,
            "earnings_usd": earnings_usd,
        })
        if len(history) > MAX_ENTRIES:
            history = history[-MAX_ENTRIES:]
        STATS_PATH.write_text(json.dumps(history))
    except Exception:
        pass


def _load_raw() -> list:
    if not STATS_PATH.exists():
        return []
    try:
        return json.loads(STATS_PATH.read_text())
    except Exception:
        return []


def get_totals() -> dict:
    """All-time totals from the retained history window (oldest entries roll
    off past MAX_ENTRIES, so 'all-time' is really 'all-retained-time')."""
    history = _load_raw()
    now_s = time.time()
    today_cutoff = int((now_s - (now_s % 86400)) * 1000)  # UTC midnight, rough but consistent
    return {
        "jobs_total": len(history),
        "tokens_total": sum(e.get("tokens", 0) for e in history),
        "bytes_total": sum(e.get("bytes_transferred", 0) for e in history),
        "rented_hours_total": sum(e.get("duration_s", 0) for e in history) / 3600.0,
        "earnings_usd_total": sum(e.get("earnings_usd", 0.0) for e in history),
        "earnings_usd_today": sum(
            e.get("earnings_usd", 0.0) for e in history
            if e.get("ts_ms", 0) >= today_cutoff
        ),
    }


def get_hourly_series(hours: int = 24) -> List[dict]:
    """Bucket the history into `hours` hourly buckets ending now, for
    charting. Each bucket: {ts_ms, bytes_transferred, rented_hours, earnings_usd}."""
    now_ms = int(time.time() * 1000)
    bucket_ms = 3600_000
    buckets = {}
    cutoff = now_ms - hours * bucket_ms
    for e in _load_raw():
        ts = e.get("ts_ms", 0)
        if ts < cutoff:
            continue
        bucket_start = ts - (ts % bucket_ms)
        b = buckets.setdefault(bucket_start, {"bytes": 0, "seconds": 0.0, "earnings_usd": 0.0})
        b["bytes"] += e.get("bytes_transferred", 0)
        b["seconds"] += e.get("duration_s", 0)
        b["earnings_usd"] += e.get("earnings_usd", 0.0)

    series = []
    for i in range(hours):
        bucket_start = now_ms - (now_ms % bucket_ms) - (hours - 1 - i) * bucket_ms
        b = buckets.get(bucket_start, {"bytes": 0, "seconds": 0.0, "earnings_usd": 0.0})
        series.append({
            "ts_ms": bucket_start,
            "bytes_transferred": b["bytes"],
            "rented_hours": b["seconds"] / 3600.0,
            "earnings_usd": b["earnings_usd"],
        })
    return series
