"""
Svitlo Chain Node Agent — запускається на ПК провайдера.

Що робить:
  1. Реєструється на платформі (один раз)
  2. Кожні 30с надсилає heartbeat (GPU stats)
  3. Слухає на HTTP-порту — приймає inference jobs від платформи
  4. Виконує inference, генерує SHA256 proof, повертає результат
  5. Платформа перераховує заробіток (SVIT) на Svitlo Chain wallet

Запуск:
  SVITLO_API_KEY=<your-key> SVITLO_WALLET=<svitlo-chain-wallet-64hex> python agent.py
"""
import asyncio
import json
import os
import platform
import socket
from datetime import datetime, timezone

from typing import Optional

import httpx
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from gpu_monitor import get_system_stats, get_gpu_specs
from inference_worker import run_inference
from proof import generate_proof

# --- Config ---
PLATFORM_URL = os.environ.get("SVITLO_PLATFORM_URL",
               os.environ.get("SVITLO_PLATFORM_URL", "http://localhost:8000"))
API_KEY = os.environ.get("SVITLO_API_KEY",
          os.environ.get("SVITLO_API_KEY", ""))
WALLET  = os.environ.get("SVITLO_WALLET",
          os.environ.get("SVITLO_WALLET", ""))
NODE_PORT = int(os.environ.get("SVITLO_NODE_PORT",
                os.environ.get("SVITLO_NODE_PORT", "8001")))
NODE_NAME = os.environ.get("SVITLO_NODE_NAME",
            os.environ.get("SVITLO_NODE_NAME", socket.gethostname()))
PRICE_PER_TOKEN = float(os.environ.get("SVITLO_PRICE_PER_TOKEN",
                         os.environ.get("SVITLO_PRICE_PER_TOKEN", "0.0000017")))
HEARTBEAT_INTERVAL = 30
ENABLE_WG_AUTH = os.environ.get("SVITLO_WG_AUTH", "1") not in ("0", "false", "no")

# Svitlo Chain wallet address: 64 lowercase hex chars (Ed25519 pubkey) — same format
# platform's backend/api/routes/nodes.py and core/auth.py check.
import re as _re
_WALLET_RE = _re.compile(r"^[0-9a-f]{64}$")

# Моделі що підтримуємо (фільтруємо за наявністю файлів)
from inference_worker import MODEL_FILES, MODELS_DIR
SUPPORTED_MODELS = [
    m for m, f in MODEL_FILES.items()
    if os.path.exists(os.path.join(MODELS_DIR, f))
] or ["llama3-8b", "mistral-7b", "phi-3-mini"]   # fallback для тестування

NODE_ID: str = ""

# --- FastAPI app (приймає jobs від платформи) ---

app = FastAPI(title="Svitlo Chain Node Agent", docs_url=None)


class JobPayload(BaseModel):
    job_id: str
    model: str
    prompt: str
    max_tokens: int = 512
    temperature: float = 0.7
    # Real bug found live 2026-08-09: `str = None` is NOT the same as
    # Optional[str] under pydantic v2 -- it stayed a required-string field
    # that only happened to default to None, so any job submitted without a
    # system_prompt (the common case) made this endpoint's own validation
    # reject the request with 422, before inference ever ran.
    system_prompt: Optional[str] = None


@app.post("/inference")
async def handle_inference(payload: JobPayload):
    """Приймає inference job від платформи."""
    global NODE_ID
    if not NODE_ID:
        raise HTTPException(503, "Node not registered yet")

    try:
        result = run_inference(
            model_name=payload.model,
            prompt=payload.prompt,
            max_tokens=payload.max_tokens,
            temperature=payload.temperature,
            system_prompt=payload.system_prompt,
        )
    except Exception as e:
        raise HTTPException(500, str(e))

    ts, proof = generate_proof(
        job_id=payload.job_id,
        node_id=NODE_ID,
        prompt=payload.prompt,
        output=result.output,
    )

    from stats_tracker import record_job
    tokens_total = result.tokens_prompt + result.tokens_completion
    record_job(
        tokens=tokens_total,
        bytes_transferred=len(payload.prompt.encode()) + len(result.output.encode()),
        duration_s=result.latency_ms / 1000.0,
        earnings_usd=tokens_total * PRICE_PER_TOKEN,
    )

    return {
        "job_id": payload.job_id,
        "node_id": NODE_ID,
        "output": result.output,
        "tokens_prompt": result.tokens_prompt,
        "tokens_completion": result.tokens_completion,
        "latency_ms": result.latency_ms,
        "proof_hash": proof,
        "timestamp": ts,
    }


@app.get("/health")
async def health():
    stats = get_system_stats()
    return {
        "node_id": NODE_ID,
        "name": NODE_NAME,
        "status": "online",
        "gpu_utilization": stats.primary_gpu_util,
        "vram_used_gb": stats.primary_vram_used,
    }


# --- Registration & Heartbeat ---

async def register():
    """Реєстрація на платформі при старті."""
    global NODE_ID
    stats = get_system_stats()
    gpu_specs = get_gpu_specs() or [{"name": "CPU-only", "vram_gb": 0}]

    payload = {
        "name": NODE_NAME,
        "wallet": WALLET,
        "gpu_specs": gpu_specs,
        "cpu_cores": os.cpu_count() or 4,
        "ram_gb": round(stats.ram_total_gb, 1),
        "supported_models": SUPPORTED_MODELS,
        "price_per_token": PRICE_PER_TOKEN,
        # Running the agent is the acceptance action for now -- there's no
        # separate consent UI yet (SetupWizard doesn't show terms text).
        # terms_version deliberately omitted: the backend only checks it for
        # a mismatch when non-empty, so omitting it just skips that check
        # rather than needing to keep a version string in sync here.
        "terms_accepted": True,
    }

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{PLATFORM_URL}/api/v1/nodes/register",
            json=payload,
            headers={"X-API-Key": API_KEY},
            timeout=10.0,
        )
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            print(f"❌ Registration failed ({resp.status_code}): {detail}")
            raise SystemExit(1)
        data = resp.json()

    NODE_ID = data["node_id"]
    print(f"✅ Registered as node {NODE_ID}")
    print(f"   Models: {', '.join(SUPPORTED_MODELS)}")
    print(f"   GPU: {[g['name'] for g in gpu_specs]}")
    print(f"   Price: ${PRICE_PER_TOKEN:.7f}/token")
    print(f"   Wallet: {WALLET[:8]}...{WALLET[-4:]}" if WALLET else "   ⚠️  No wallet set")


async def heartbeat_loop():
    """Надсилає heartbeat кожні 30с."""
    global NODE_ID
    await asyncio.sleep(5)  # дати час реєстрації

    while True:
        try:
            stats = get_system_stats()
            payload = {
                "node_id": NODE_ID,
                "gpu_utilization": stats.primary_gpu_util,
                "vram_used_gb": stats.primary_vram_used,
                "cpu_utilization": stats.cpu_utilization,
                "ram_used_gb": stats.ram_used_gb,
                "active_jobs": 0,   # TODO: трекати активні jobs
                "status": "online",
            }
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{PLATFORM_URL}/api/v1/nodes/heartbeat",
                    json=payload,
                    headers={"X-API-Key": API_KEY},
                    timeout=5.0,
                )
        except Exception as e:
            print(f"⚠️  Heartbeat failed: {e}")

        await asyncio.sleep(HEARTBEAT_INTERVAL)


# --- Main ---

async def main():
    if not API_KEY:
        print("❌ Set SVITLO_API_KEY environment variable")
        return
    if WALLET and not _WALLET_RE.match(WALLET.lower()):
        print("❌ SVITLO_WALLET is not a valid Svitlo Chain address (expected 64 hex chars)")
        return

    print(f"Svitlo Node Agent starting on port {NODE_PORT}...")

    # WireGuard мережева авторизація (перед реєстрацією на платформі)
    if ENABLE_WG_AUTH:
        try:
            from wg_connect import authenticate_and_connect
            vpn_ip = await authenticate_and_connect()
            if vpn_ip:
                print(f"WireGuard connected: {vpn_ip}")
            else:
                print("WireGuard auth skipped (no SVIT_PRIVATE_KEY or wg not installed)")
        except Exception as e:
            print(f"WireGuard auth failed (non-fatal): {e}")

    await register()

    # Запускаємо heartbeat у фоні
    asyncio.create_task(heartbeat_loop())

    # Запускаємо HTTP server
    config = uvicorn.Config(app, host="0.0.0.0", port=NODE_PORT, log_level="warning")
    server = uvicorn.Server(config)
    await server.serve()


if __name__ == "__main__":
    asyncio.run(main())
